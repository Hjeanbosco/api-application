-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 19, 2023 at 10:29 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bosco_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(30) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `number` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstName`, `lastName`, `gender`, `email`, `password`, `number`) VALUES
(1, 'bosc1234', 'hategekimana', 'male', 'bosco@gmail.com', '$2a$10$1DEK5f3uYcPTRP6fqKr46Ox09mGdWMKtOWX5uo5wXiWf/uqgKZ2mm', 785341235),
(8, 'kik00i111', 'dudu111', 'male', 'bosco@gmail.com', '$2a$10$FtdrI6QHTvCeL.4fa6Fcmu9qiiEAF.f4Z5L88kVdIAuRVxbWcn2WO', 731111111),
(23, 'dudu', 'jeanbosco', 'male', 'hategekimanajeanbosco@gmail.com', '$2a$10$DhsOtGszpQkESZ8uUW7ZLuV1G/jgV2TbhS22j1QI/bBtDqluThrfG', 785323931),
(24, 'manzi', 'fiston', 'male', 'fiston@gmail.com', '$2a$10$cBOxjJTP.XBupmB8uu1MpO2ok7nJUvs4HvF9azZdVQDHlq7uKY.ai', 785323931),
(26, 'kaliza', 'manzi', 'gender', 'kaliza@gmail.com', '$2a$10$6Y4RFh0PDRsZpDHkkt.QTed7egu3H0VRkm8D9FtJ9RaoC9MvcERqW', 785341235),
(27, 'hategekimana', 'jeanbosco', 'male', 'hategekimanajeanbosco@gmail.com', '$2a$10$tXit2IESVEBqGCA6D3qTk.jQgqWHK5z5xhTrEGrZOWCUvnFuDX1kC', 785323931),
(28, 'kalisa', 'neema', 'female', 'bosc1234@gmail.com', '$2a$10$JFVnGUro4v3QhtOjzG/yHO2haOJ6C/ph5g1xb7vbVqQaocTC/rAH6', 70953235),
(31, 'didi', 'vivi', 'female', 'didi@gmail.com', '$2a$10$/9tK6IL9miENIvphN5OifOZr5LlDkWgtX4NgStv/uNwuCCysj.BGm', 709235),
(32, 'gf', 'dhh', 'm', 'gd@gmail.com', '$2a$10$w7hgb78AQeG5ni2ydlwnzuyJydkF35N5OE8TwTkFb/ABWPQ86gELW', 66845);

-- --------------------------------------------------------

--
-- Table structure for table `students_marks`
--

CREATE TABLE `students_marks` (
  `m_id` int(11) NOT NULL,
  `cat` int(11) NOT NULL,
  `exam` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students_marks`
--

INSERT INTO `students_marks` (`m_id`, `cat`, `exam`, `total`, `id`) VALUES
(1, 20, 30, 50, 1),
(2, 34, 30, 64, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_marks`
--
ALTER TABLE `students_marks`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `students_marks`
--
ALTER TABLE `students_marks`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
