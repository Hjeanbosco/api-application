this project is for api
it contains two folders, frontend and server
front is developed in reacy js while backend developed in node js and express
also you can test it using postman and it contains different methods like put,delete,post and get, you can get all users or you can get user by id
this project also is authonticated by jwt where you have to login and veryfy tocken before performing crud operation 
