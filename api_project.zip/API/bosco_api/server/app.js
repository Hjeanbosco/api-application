require("dotenv").config();
const cors = require('cors');
const express = require("express");
const app = express();
const userRouter = require("./api/users/user_router");
const swaggerJSDoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

app.use(cors());
app.use(express.json());
app.use("/api/users", userRouter);
app.listen(process.env.APP_PORT, () => {
    console.log("Server up and running", process.env.APP_PORT);
});

const swaggerOptions ={
    swaggerDefinition: {
        openapi: '3.0.0',
        info: {
          title: 'User Api Documentation using Swagger',
          version: '0.1.0',
          description : 
            "User Rigistration API information, this api is allowed to accessing data of registerd users in database and you can make other some operations",
          contact: {
            name:"API Developer HATEGEKIMANA JeanBosco",
            email:"hatejeanbosco2@gmail.com",
            url: "bosco.com",
        },
    },
           servers:[
           {
            url: "http://localhost:5000/",
           },
        ],
},
apis: ['./api/users/*.js'],
};
const swaggerDocs = swaggerJSDoc(swaggerOptions)
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs))