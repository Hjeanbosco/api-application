const express = require("express");
const cors = require("cors");
const { createUser,
     getUserByUserId,
    getUsers, 
      updateUsers,
       deleteUser,
       login
     } = require("./user_controller");
 const app = express();
app.use(cors());
     
const router = require("express").Router();
const { checkToken } = require("../../auth/token_validation");
router.post("/", createUser);
router.get("/", getUsers);
router.get("/:id", getUserByUserId);
router.put("/:id", updateUsers);
router.delete("/:id",deleteUser);
router.post("/login", login);
 
/**
* @swagger
* components:
*   schemas:
*     Users:
*       type: object
*       properties:
*         firstName:
*           type: string
*           description: enter your first name
*           example: hategekimana
*         lastName:
*           type: string
*           description: enter your last name
*           example: jeanbosco
*         password:
*           type: string
*           description: enter your user password
*           example: bosco@12345
*         email:
*           type: string
*           description: enter your email
*           example: jeanbosco@gmail.com
*         number:
*           type: string
*           description: enter your phone number
*           example: 0785323931
*/
/**
 * @swagger
 * /api/users:
 *  get:
 *    tags:
 *      - Users
 *    summary: Retrieve a list of students
 *    description: Retrieve a list of task froma registration table
 *    responses:
 *      200:
 *        description: A list of students.
 *        content: 
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                description:
 *                  type: string
 *                  example: Successfully fetched all students data!
 *                data:
 *                  type: array
 *                  items:
 *                    $ref: '#/components/schemas/Users'
 * 
 */
router.get("/", checkToken, getUsers);
/**
 * @swagger
 * /api/users/{id}:
 *    get:
 *      tags:
 *        - Users
 *      summary: Retrieve student data by id
 *      description: Retrieve users by id from registration table
 *      parameters:
 *        - name: id
 *          in: path
 *          required: true
 *          description: user id
 *          schema:
 *            type: integer
 *            format: int64
 *      responses:
 *        200:
 *          description: single student data.
 *          content: 
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  description:
 *                    type: string
 *                    example: Successfully fetched student data by id!
 *                  data:
 *                    type: object
 *                    properties:
 *                      firstName:
 *                        type: string
 *                        description: enter your fistName
 *                        example: hategekimana
 *                      lastName:
 *                        type: string
 *                        description: enter your lastName
 *                        example: jeanbosco
 *                      email:
 *                        type: string
 *                        description: enter your email
 *                        example: hategekimanajeanbosco@gmail.com
 *                      gender:
 *                        type: string
 *                        description: enter your gender
 *                        example: male
 *                      password:
 *                        type: string
 *                        description: enter your password
 *                        example: bosco12345
 *                      number:
 *                        type: string
 *                        description: enter your phone number
 *                        example: 0785323931
 * 
 */
router.get("/:id", checkToken, getUserByUserId);

/**
 * @swagger
 * /api/users/:
 *    post:
 *      tags:
 *        - Users
 *      description: Create stydent with API
 *      summary: Create student data
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                firstName:
 *                  type: string
 *                  description: enter your fistName
 *                  example: hategekimana
 *                lastName:
 *                  type: string
 *                  description: enter your lastName
 *                  example: jeanbosco
 *                email:
 *                  type: string
 *                  description: enter your email
 *                  example: hategekimanajeanbosco@gmail.com
 *                gender:
 *                  type: string
 *                  description: enter your gender
 *                  example: male
 *                password:
 *                  type: string
 *                  description: enter your password
 *                  example: bosco12345
 *                number:
 *                  type: string
 *                  description: enter your phone number
 *                  example: 0785323931
 *      responses:
 *        200:
 *          description: Successfully created data
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  description:
 *                    type: string
 *                    example: Successfully created data! 
 *                
 */
router.post("/", checkToken, createUser);
/**
 * @swagger
 * /api/users/{id}:
 *    put:
 *      tags:
 *        - Users
 *      summary: Update student data
 *      description: update student data API
 *      parameters:
 *        - name: id
 *          in: path
 *          required: true
 *          description: student id
 *          schema:
 *            type: integer
 *            format: int64
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                firstName:
 *                  type: string
 *                  description: enter your fistName
 *                  example: hategekimana
 *                lastName:
 *                  type: string
 *                  description: enter your lastName
 *                  example: jeanbosco
 *                email:
 *                  type: string
 *                  description: enter your email
 *                  example: hategekimanajeanbosco@gmail.com
 *                gender:
 *                  type: string
 *                  description: enter your gender
 *                  example: male
 *                password:
 *                  type: string
 *                  description: enter your password
 *                  example: bosco12345
 *                number:
 *                  type: string
 *                  description: enter your phone number
 *                  example: 0785323931
 *      responses:
 *        200:
 *          description: Successfully updated student data
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  description:
 *                    type: string
 *                    example: Successfully updated student data! 
 * 
 *      
 */
router.put("/:id", checkToken, updateUsers);
/**
 * @swagger
 * /api/users/{id}:
 *    delete:
 *      tags:
 *        - Users
 *      summary: Remove student data by id
 *      description: Remove student API  
 *      parameters:
 *        - name: id
 *          in: path
 *          required: true
 *          description: Users id
 *          schema:
 *            type: integer
 *            format: int64
 *      responses:
 *        200:
 *          description: Successfully deleted data
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  description:
 *                    type: string
 *                    example: Successfully updated data!     
 * 
 * 
 */
router.delete("/:id", checkToken, deleteUser);
module.exports =router;