import React from 'react'
import './App.css'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import Home from './Home'
import Create from './Create'
import Edit from './Edit'
import Detail from './Details'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
function App() {
    return (
      <div>
        <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/create' element={<Create />}></Route>
          <Route path='/detail/:id' element={<Detail />}></Route>
          <Route path='/edit/:id' element={<Edit />}></Route>
        </Routes>
      </BrowserRouter>
    
      </div>
      );
    
  }

export default App;
