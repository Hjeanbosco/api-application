import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const Detail = () => {
    const { id } = useParams();
    const [data, setData] = useState({});

    useEffect(() => {
        fetch("http://localhost:5000/api/users/" + id)
            .then((res) => res.json())
            .then((resp) => {
                setData(resp.data);
            })
            .catch((err) => {
                console.log(err.message);
            });
    }, [id]);

    return (
        <div>
            <div className="container">
                <div className="card row" style={{ "textAlign": "left" }}>
                    <div className="card-title">
                        <h2>Student Details</h2>
                    </div>
                    <div className="card-body"></div>

                    {data && (
                        <div>
                            <h5>ID is: {data.id}</h5>
                            <h5>firstName is: {data.firstName}</h5>
                            <h5>lastName is: {data.lastName}</h5>
                            <h5>Email is: {data.email}</h5>
                            <h5>Gender is: {data.gender}</h5>
                            <h5>Phone is: {data.number}</h5>
                            <Link className="btn btn-danger" to="/">Back to Listing</Link>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default Detail;
