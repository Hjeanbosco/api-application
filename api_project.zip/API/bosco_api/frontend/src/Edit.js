import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const Edit = () => {
    const { id } = useParams();
    const [data, setData] = useState({});

    useEffect(() => {
        fetch("http://localhost:5000/api/users/" + id)
            .then((res) => res.json())
            .then((resp) => {
                setData(resp.data);
            })
            .catch((err) => {
                console.log(err.message);
            });
    }, [id]);

    return (
      <div className="row">
      <div className="offset-lg-3 col-lg-6">
          <form className="container" method="post">

              <div className="card" style={{"textAlign":"left"}}>
                  <div className="card-title">
                      <h2>Student Edit</h2>
                  </div>
                  <div className="card-body">

                      <div className="row">

                    {data && (
                        <div>
                    
                          <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>ID</label>
                                        <input value={data.id} disabled="disabled" className="form-control"></input>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>firstName</label>
                                        <input value={data.firstName} className="form-control"></input>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>lastName</label>
                                        <input value={data.lastName} className="form-control"></input>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>email</label>
                                        <input value={data.email} className="form-control"></input>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>gender</label>
                                        <input value={data.gender} className="form-control"></input>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group">
                                        <label>number</label>
                                        <input value={data.number} className="form-control"></input>
                                    </div>
                                </div>
                                <div className="form-group">
                                       <button className="btn btn-success" type="submit">Save</button>
                                       <Link to="/" className="btn btn-danger">Back</Link>
                                    </div>
                        </div>
                        
                    )}
                    
                   </div>
                   

</div>

</div>

</form>

</div>
</div>
    );
}

export default Edit;
