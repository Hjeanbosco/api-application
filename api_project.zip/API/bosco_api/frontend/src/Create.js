import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Create = () => {
  const [id, idchange] = useState("");
  const [firstName, firstNamechange] = useState("");
  const [lastName, lastNamechange] = useState("");
  const [email, emailchange] = useState("");
  const [gender, genderchange] = useState("");
  const [number, numberchange] = useState("");
  const [password, passwordchange] = useState("");
  const [active, activechange] = useState(true);
  const [validation, valchange] = useState(false);

  const navigate = useNavigate();

  const handlesubmit = (e) => {
    e.preventDefault();
    const data = { firstName, lastName, email, gender, number, password, active };

    fetch("http://localhost:5000/api/users/", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(data),
    })
      .then((res) => {
        alert("Saved successfully.");
        navigate("/");
      })
      .catch((err) => {
        console.log(err.message);
      });
  };

  return (
    <div>
      <div className="row">
        <div className="offset-lg-3 col-lg-6">
          <form className="container" onSubmit={handlesubmit}>
            <div className="card" style={{ textAlign: "left" }}>
              <div className="card-title">
                <h2>Student Create</h2>
              </div>
              <div className="card-body">
                <div className="row">
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>ID</label>
                      <input
                        value={id}
                        disabled="disabled"
                        className="form-control"
                      ></input>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>FIRSTNAME</label>
                      <input
                        required
                        value={firstName}
                        onMouseDown={(e) => valchange(true)}
                        onChange={(e) => firstNamechange(e.target.value)}
                        className="form-control"
                      ></input>
                      {firstName.length == 0 && validation && (
                        <span className="text-danger">
                          Enter the firstName
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>LASTNAME</label>
                      <input
                        required
                        value={lastName}
                        onMouseDown={(e) => valchange(true)}
                        onChange={(e) => lastNamechange(e.target.value)}
                        className="form-control"
                      ></input>
                      {lastName.length == 0 && validation && (
                        <span className="text-danger">
                          Enter the laststName
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>Email</label>
                      <input
                        value={email}
                        onChange={(e) => emailchange(e.target.value)}
                        className="form-control"
                      ></input>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>Gender</label>
                      <input
                        value={gender}
                        onChange={(e) => genderchange(e.target.value)}
                        className="form-control"
                      ></input>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>Number</label>
                      <input
                        value={number}
                        onChange={(e) => numberchange(e.target.value)}
                        className="form-control"
                      ></input>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <label>password</label>
                      <input
                        value={password}
                        onChange={(e) => passwordchange(e.target.value)}
                        className="form-control"
                      ></input>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-check">
                      <input
                        checked={active}
                        onChange={(e) => activechange(e.target.checked)}
                        type="checkbox"
                        className="form-check-input"
                      ></input>
                      <label className="form-check-label">Is Active</label>
                    </div>
                  </div>
                  <div className="col-lg-12">
                    <div className="form-group">
                      <button className="btn btn-success" type="submit">
                        Save
                      </button>
                      <Link to="/" className="btn btn-danger">
                        Back
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Create;
