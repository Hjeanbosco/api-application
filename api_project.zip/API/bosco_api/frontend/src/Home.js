import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Home = () => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const LoadDetail = (id) => {
    navigate("detail/" + id);
  };

  const LoadEdit = (id) => {
    navigate("edit/" + id);
  };

  const RemoveFunction = (id) => {
    if (window.confirm("Do you want to remove this student?")) {
      fetch("http://localhost:5000/api/users/" + id, {
        method: "DELETE",
      })
        .then((res) => {
          alert("Student removed successfully.");
          window.location.reload();
        })
        .catch((err) => {
          console.log(err.message);
        });
    }
  };

  useEffect(() => {
    fetch("http://localhost:5000/api/users/")
      .then((res) => res.json())
      .then((resp) => {
        setData(resp.data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.log(err.message);
        setIsLoading(false);
      });
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  const renderTableRows = () => {
    if (!data || data.length === 0) {
      return <tr><td colSpan={9}>No data available</td></tr>;
    }
    
    const rows = [];
    for (let i = 0; i < data.length; i++) {
      const registration = data[i];
      rows.push(
        <tr key={registration.id}>
          <td>{registration.id}</td>
          <td>{registration.firstName}</td>
          <td>{registration.lastName}</td>
          <td>{registration.gender}</td>
          <td>{registration.email}</td>
          <td>{registration.number}</td>
          <td>
            <a
              onClick={() => LoadEdit(registration.id)}
              className="btn btn-success"
            >
              Edit
            </a>
          </td>
          <td>
            <a
              onClick={() => RemoveFunction(registration.id)}
              className="btn btn-danger"
            >
              Remove
            </a>
          </td>
          <td>
            <a
              onClick={() => LoadDetail(registration.id)}
              className="btn btn-primary"
            >
              View
            </a>
          </td>
        </tr>
      );
    }
    return rows;
  };

  return (
    <div className="container">
      <div className="card">
        <div className="card-title">
          <h2>Student List</h2>
        </div>
        <div className="card-body">
          <div className="divbtn">
            <Link to="/create" className="btn btn-success">
              Add New (+)
            </Link>
          </div>
          <table className="table table-bordered">
            <thead className="bg-dark text-white">
              <tr>
                <td>ID</td>
                <td>FIRSTNAME</td>
                <td>LASTNAME</td>
                <td>GENDER</td>
                <td>EMAIL</td>
                <td>TELPHONEPHONE</td>
                <td colSpan={3}>Action</td>
              </tr>
            </thead>
            <tbody>
              {renderTableRows()}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Home;
