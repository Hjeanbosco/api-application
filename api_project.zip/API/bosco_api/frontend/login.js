const loginBtn = document.getElementById("login-btn");
const protectedBtn = document.getElementById("protected-btn");
const resultDiv = document.getElementById("result");

loginBtn.addEventListener("click", () => {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;

  // Send login request to server
  fetch("http://localhost:3000/api/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ username: username, password: password }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Store the token in local storage or session storage
        localStorage.setItem("token", data.token);
        resultDiv.textContent = "Login successful!";
      } else {
        resultDiv.textContent = data.message;
      }
    })
    .catch((error) => {
      console.log(error);
      resultDiv.textContent = "An error occurred.";
    });
});

protectedBtn.addEventListener("click", () => {
  const token = localStorage.getItem("token");

  // Send protected route request to server
  fetch("http://localhost:3000/api/protected", {
    headers: {
      Authorization: "Bearer " + token,
    },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        resultDiv.textContent = data.message;
      } else {
        resultDiv.textContent = data.message;
      }
    })
    .catch((error) => {
      console.log(error);
      resultDiv.textContent = "An error occurred.";
    });
});
